-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : nanzhuanggaoding
-- 
-- Part : #1
-- Date : 2017-07-12 11:17:35
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `ads`
-- -----------------------------
DROP TABLE IF EXISTS `ads`;
CREATE TABLE `ads` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `thumb` varchar(128) NOT NULL,
  `url` varchar(256) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `type` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ads`
-- -----------------------------
INSERT INTO `ads` VALUES ('16', '\\static\\upload\\ads\\20170619\\s_f49f03d3aaa9c73399f1c9cf510b7fa5.png', '\\static\\upload\\ads\\20170619\\f49f03d3aaa9c73399f1c9cf510b7fa5.png', '1', '1');
